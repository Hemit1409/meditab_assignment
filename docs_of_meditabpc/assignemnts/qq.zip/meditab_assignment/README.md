# meditab_assignment
 
https://iemodemoindia.meditab.com/#/app/main
code: training
usernames and passwords: rajp and rajp

https://docs.google.com/document/d/1bgsotd2UOZXW996ebkGLsMtIKP5ysBk15qP-aVNx0f4/edit?usp=sharing
