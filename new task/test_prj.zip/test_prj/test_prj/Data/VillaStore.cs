﻿using test_prj.Models.DTO;

namespace test_prj.Data
{
    public static class VillaStore
    {
        public static List<VillaDTO> VillaList = new List<VillaDTO> {

            new VillaDTO { Id = 1, Name="HEMIT",Sqft=100,occupancy=4 },
            new VillaDTO { Id = 2, Name="NIKITA",Sqft=200,occupancy=8}
        
        };
    }
}
