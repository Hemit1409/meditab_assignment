﻿using System.Data;

namespace WebApi_hemitr.Models
{
    public class Patients
    {
        public int patient_id { get; set; }

        public string chartnumber { get; set; } = string.Empty;
        public string first_name { get; set; } = string.Empty;
        public string last_name { get; set; } = string.Empty;
        public string middle_name { get; set; } = string.Empty;

        public int sex_id { get; set; }

        public string sex { get; set; } = string.Empty;

        public string dob { get; set; } = string.Empty;

        public bool isdeleted { get; set; }

        public DateTime created_on { get; set; }

        public DateTime modified_on { get; set; }
        /*public int PageNumber { get; set; } = 1;

        public int PageSize { get; set; } = 20;*/

        public string allergyname { get; set; } = string.Empty;

        public string note { get; set; } = string.Empty;

        public string Orderby { get; set; } = "Patients.patient_id";
        public string OrderType { get; set; } = "ASC";
        public int patientAllergyId { get; set; }
        public int allergyMasterId { get; set; }

        public string code { get; set; } = string.Empty;
        //public string allergyname { get; set; } = string.Empty;

        //Created[] created_ = new Created[10];
        /*public Allergy[]? created_ { get; set; }
        public Allergy[]? deleted_ { get; set; }
        public Allergy[]? updated_ { get; set; }*/

        public PatientAllergy? Allergy { get; set; }

        //created_[0]=

        public static List<Patients> GetListByTable(DataTable dt)
        {

            var ModelList = (from rw in dt.AsEnumerable()
                             select new Patients()
                             {
                                 patient_id = (int)(rw["patientid"]),
                                 first_name = (string)(rw["firstname"]),
                                 last_name = (string)(rw["lastname"]),
                                 chartnumber = (string)(rw["chart_number"]),

                                 dob = ((DateTime)(rw["dob"])).ToString(),
                                 sex = (string)(rw["sex"]),
                                 allergyname = (rw["AllergyName"] == null) ? string.Empty : rw["AllergyName"].ToString(),
                                 note = (rw["Note"] == null) ? string.Empty : rw["Note"].ToString(),
                                 code = (rw["code"] == null) ? string.Empty : rw["code"].ToString()
                             }).ToList();
            return ModelList;
        }
        //(rw["Note"] == null) ? string.Empty : rw["Note"].ToString()
        public static List<Patients> GetListByID(DataTable dt)
        {

            var ModelList = (from rw in dt.AsEnumerable()
                             select new Patients()
                             {
                                 patient_id = (int)(rw["patient_id"]),
                                 chartnumber = (string)(rw["chart_number"]),
                                 first_name = (string)(rw["firstname"]),
                                 last_name = (string)(rw["lastname"]),
                                 middle_name = (string)(rw["middlename"]),
                                 sex = (string)(rw["sex"]),
                                 dob = ((DateTime)(rw["dob"])).ToString(),
                                 sex_id = (int)(rw["sex_id"]),
                                 allergyname = (rw["AllergyName"] == null) ? string.Empty : rw["AllergyName"].ToString(),
                                 note = (rw["Note"] == null) ? string.Empty : rw["Note"].ToString(),
                                 code = (rw["code"] == null) ? string.Empty : rw["code"].ToString()
                             }).ToList();
            return ModelList;
        }
        

    }

    public class Functions
    {
        public bool? Checknull { get; set; }
    }

    public class Pagination
    {

    }
}
