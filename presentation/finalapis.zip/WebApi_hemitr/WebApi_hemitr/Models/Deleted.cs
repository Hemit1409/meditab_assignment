﻿namespace WebApi_hemitr.Models
{
    public class Deleted
    {
        public int patientid { get; set; }
        public string allergyname { get; set; } = string.Empty;

        public string note { get; set; } = string.Empty;

        public int patientAllergyId { get; set; }
        public int allergyMasterId { get; set; }
    }
}
