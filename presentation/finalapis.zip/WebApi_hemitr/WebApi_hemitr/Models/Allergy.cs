﻿using System.Data;

namespace WebApi_hemitr.Models
{
    public class Allergy
    {
        //public int patientid { get; set; }
        public string allergyname { get; set; } = string.Empty;

        public string note { get; set; } = string.Empty;

        public int patientAllergyId { get; set; }
        public int allergyMasterId { get; set; }

        /*public Created(int pid, string an, string nt, int paid, int amid) {

            patient_id = pid;
            allergyname = an;
            allergyMasterId = amid;
            note = nt;
            patientAllergyId = paid;
        
        }*/
        public static Allergy GetListAllergyrow(DataRow rw)
        {
            Allergy allergy = new Allergy();

            //patientid = (int)(rw["patient_id_"]),

            allergy.patientAllergyId = (int)(rw["_PatientAllergyId"]);

            allergy.allergyMasterId = (int)(rw["_AlergyMasterID"]);

            allergy.allergyname = (rw["_AllergyName"] == null) ? string.Empty : rw["_AllergyName"].ToString();
            allergy.note = (rw["_Note"] == null) ? string.Empty : rw["_Note"].ToString();



            return allergy;
        }



        public static List<Allergy> GetListAllergy3(DataTable dt)
        {

            var modelList = (from rw in dt.AsEnumerable()
                             select new Allergy()
                             {
                                 //patientid = (int)(rw["patient_id_"]),

                                 patientAllergyId = (int)(rw["PatientAllergyId_"]),

                                 allergyMasterId = (int)(rw["AllergyMasterId_"]),

                                 allergyname = (rw["AllergyName_"] == null) ? string.Empty : rw["AllergyName_"].ToString(),
                                 note = (rw["Note_"] == null) ? string.Empty : rw["Note_"].ToString(),


                             }).ToList();
            return modelList;
        }


    }

    
}
