﻿namespace WebApi_hemitr.Models
{
    public class PatientAllergy
    {
        public Allergy[]? created_ { get; set; }
        public Allergy[]? deleted_ { get; set; }
        public Allergy[]? updated_ { get; set; }
    }
}
