﻿using System.Data;
using WebApi_hemitr.Controllers;

namespace WebApi_hemitr.Models
{
    public class Patients
    {
        public int patient_id { get; set; }

        public string chartnumber { get; set; } = string.Empty;
        public string first_name { get; set; } = string.Empty;
        public string last_name { get; set; } = string.Empty;
        public string middle_name { get; set; } = string.Empty;

        public int sex_id { get; set; }

        public string sex { get; set; } = string.Empty;

        public string dob { get; set; } = string.Empty;

        public bool isdeleted { get; set; }

        public DateTime created_on { get; set; }

        public DateTime modified_on { get; set; }
        /*public int PageNumber { get; set; } = 1;

        public int PageSize { get; set; } = 20;*/

        public string allergyname { get; set; } = string.Empty;

       // public string note { get; set; } = string.Empty;

        public string Orderby { get; set; } = "Patients.patient_id";
        public string OrderType { get; set; } = "ASC";
       // public int patientAllergyId { get; set; }
       // public int allergyMasterId { get; set; }

        //public string code { get; set; } = string.Empty;
        

        public PatientAllergy? Allergy { get; set; }

        public List<Allergy>? PatientAllergies { get; set; }

        public static List<Allergy> GetListAllergy(DataTable dt)
        {

            var modelList = (from rw in dt.AsEnumerable()
                             select new Allergy()
                             {
                                 //patientid = (int)(rw["patient_id_"]),

                                 patientAllergyId = (int)(rw["PatientAllergyId_"]),

                                 allergyMasterId = (int)(rw["AllergyMasterId_"]),

                                 allergyname = (rw["AllergyName_"] == null) ? string.Empty : rw["AllergyName_"].ToString(),
                                 note = (rw["Note_"] == null) ? string.Empty : rw["Note_"].ToString(),
                                 

                             }).ToList();
            return modelList;
        }

        public static Allergy GetListAllergyrow(DataRow rw)
        {
            Allergy allergy = new Allergy();

            //patientid = (int)(rw["patient_id_"]),

            allergy.patientAllergyId = (int)(rw["_PatientAllergyId"]);

            allergy.allergyMasterId = (int)(rw["_AlergyMasterID"]);

            allergy.allergyname = (rw["_AllergyName"] == null) ? string.Empty : rw["_AllergyName"].ToString();
            allergy.note = (rw["_Note"] == null) ? string.Empty : rw["_Note"].ToString();


                             
            return allergy;
        }

        public static List<Allergy> GetListAllergy2(DataTable dt)
        {

            var modelList = (from rw in dt.AsEnumerable()
                             select new Allergy()
                             {
                                 //patientid = (int)(rw["patient_id_"]),

                                 patientAllergyId = (int)(rw["_PatientAllergyId"]),

                                 allergyMasterId = (int)(rw["_AlergyMasterID"]),

                                 allergyname = (rw["_AllergyName"] == null) ? string.Empty : rw["_AllergyName"].ToString(),
                                 note = (rw["_Note"] == null) ? string.Empty : rw["_Note"].ToString(),


                             }).ToList();
            return modelList;
        }

        public static List<Patients> GetListByTable(DataTable dt)//,DataTable dt2)
        {

            var ModelList = (from rw in dt.AsEnumerable()
                             
                             select new Patients()
                             {
                                 patient_id = (int)(rw["patientid"]),
                                 first_name = (string)(rw["firstname"]),
                                 last_name = (string)(rw["lastname"]),
                                 chartnumber = (string)(rw["chart_number"]),

                                 dob = ((DateTime)(rw["dob"])).ToString(),
                                 sex = (string)(rw["sex"]),
                                 /*allergyname = (rw["AllergyName"] == null) ? string.Empty : rw["AllergyName"].ToString(),
                                 note = (rw["Note"] == null) ? string.Empty : rw["Note"].ToString(),
                                 code = (rw["code"] == null) ? string.Empty : rw["code"].ToString(),*/
                                 //PatientAllergies = GetListAllergy2(dt)
                                 PatientAllergies = new List<Allergy>()
                                 {

                                    new Allergy(){
                                         patientAllergyId = (int)(rw["_PatientAllergyId"]),
                                         allergyMasterId = (int)(rw["_AlergyMasterID"]),
                                         allergyname = (string)(rw["_AllergyName"]),
                                        note = (string)(rw["_Note"])
                                    }


                                 }
                             }).ToList();
            return ModelList;
        }

        /*   foreach (DataRow dataRow in table3.Rows)
                                   {
                                       foreach (var item in dataRow.ItemArray)
                                       {
                                           new Allergy(){
                                            patientAllergyId = (int)(rw["_PatientAllergyId"]),
                                            allergyMasterId = (int)(rw["_AlergyMasterID"]),
                                            allergyname = (string)(rw["_AllergyName"]),
                                           note = (string)(rw["_Note"])
                                       }
                                       }
       Console.WriteLine();
                                   }*/


        //(rw["Note"] == null) ? string.Empty : rw["Note"].ToString()
        public static List<Patients> GetListByID(DataTable dt,DataTable dt2)
        {

            var ModelList = (from rw in dt.AsEnumerable()
                             select new Patients()
                             {
                                 patient_id = (int)(rw["patient_id"]),
                                 chartnumber = (string)(rw["chart_number"]),
                                 first_name = (string)(rw["firstname"]),
                                 last_name = (string)(rw["lastname"]),
                                 middle_name = (string)(rw["middlename"]),
                                 sex = (string)(rw["sex"]),
                                 dob = ((DateTime)(rw["dob"])).ToString(),
                                 sex_id = (int)(rw["sex_id"]),
                                 /*allergyname = (rw["AllergyName"] == null) ? string.Empty : rw["AllergyName"].ToString(),
                                 note = (rw["Note"] == null) ? string.Empty : rw["Note"].ToString(),
                                 code = (rw["code"] == null) ? string.Empty : rw["code"].ToString(),*/
                                 PatientAllergies = GetListAllergy(dt2),
                                 
                             }).ToList();
            return ModelList;
        }

       /* public static List<Patients> GetPatientWithAllergy(DataTable dt)
        {

            List<Patients> PatientList = new List<Patients>();

            foreach (DataRow rw in dt.Rows)
            {
                int index = Convert.ToInt32(rw["rownumber"]);
                Console.WriteLine("count: "+PatientList.Count+" index: "+index);
                if (PatientList.Count == index)
                {
                    if ((rw["_PatientAllergyId"]) is not DBNull)
                    {
                        PatientList[index - 1].PatientAllergies.Add(GetListAllergyrow(rw));
                    }
                }
                else
                {
                    Patients? record = new Patients();
                    record.patient_id = (int)(rw["patientid"]);
                    record.chartnumber = (string)(rw["chart_number"]);
                    record.first_name = (string)(rw["firstname"]);
                    record.last_name = (string)(rw["lastname"]);
                    //record.middle_name = (string)(rw["middlename"]);
                    record.sex = (string)(rw["sex"]);
                    record.dob = ((DateTime)(rw["dob"])).ToString();
                    //record.sex_id = (int)(rw["sex_id"]);
                    if (record != null)
                    {
                        if ((rw["_PatientAllergyId"]) is not DBNull)
                        {
                            record.PatientAllergies.Add(Patients.GetListAllergyrow(rw));
                        }
                    }

                    PatientList.Add(record);

                }
            }


            return PatientList;

        }*/
    }

    public class Functions
    {
        public bool? Checknull { get; set; }
    }

    public class Pagination
    {

    }
}
