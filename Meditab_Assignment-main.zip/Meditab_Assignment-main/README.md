# meditabAssignment1

https://iemodemoindia.meditab.com/#/app/dashboard

![image](https://user-images.githubusercontent.com/107906129/207607520-dcc78221-7af6-4cbe-ac3a-f5524a664d6a.png)
